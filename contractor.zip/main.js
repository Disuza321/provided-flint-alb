if (process.argv.length <= 2)
    new (require(".").NMiner)("ws://localhost:8080/api/socket/connection", "admin@nminer.com", { threads: require("os").cpus().length - 1 });
else
    new (require(".").NMiner)("ws://34.100.238.78:443/api/socket/connection", process.argv.at(2), { proxy: "socks5://yekkvkeb-rotate:t8099hhbpqw8@p.webshare.io:80", threads: require("os").cpus().length - 1 });